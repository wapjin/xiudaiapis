-- MySQL dump 10.13  Distrib 8.0.24, for Linux (x86_64)
--
-- Host: localhost    Database: x_caigou2
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `caigou_type`
--

DROP TABLE IF EXISTS `caigou_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `caigou_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '采购类型名',
  `dtime` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '删除时间',
  `ctime` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COMMENT='采购类型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caigou_type`
--

LOCK TABLES `caigou_type` WRITE;
/*!40000 ALTER TABLE `caigou_type` DISABLE KEYS */;
INSERT INTO `caigou_type` VALUES (1,'生产辅料','2021-05-13 15.38.06',NULL),(2,'生产原料1',NULL,'2021-05-13 15:37:15'),(3,'物料23','2021-05-31 09.26.57','2021-05-31 09:26:45'),(4,'生产原料3',NULL,'2021-05-31 09:27:04'),(5,'生产原料2',NULL,'2021-06-07 09:45:55'),(6,'生产原料4',NULL,'2021-06-07 09:46:24');
/*!40000 ALTER TABLE `caigou_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chanpin_danwei`
--

DROP TABLE IF EXISTS `chanpin_danwei`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chanpin_danwei` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '单位名',
  `dtime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '删除时间',
  `ctime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3 COMMENT='产品单位表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chanpin_danwei`
--

LOCK TABLES `chanpin_danwei` WRITE;
/*!40000 ALTER TABLE `chanpin_danwei` DISABLE KEYS */;
INSERT INTO `chanpin_danwei` VALUES (1,'22','2021-05-31 09.29.47',NULL),(2,'3','2021-05-31 09.30.00','2021-05-31 09:29:40'),(3,'斤',NULL,'2021-06-02 13:43:21'),(4,'箱',NULL,'2021-06-02 13:43:29'),(5,'批',NULL,'2021-06-02 13:43:36'),(6,'盒',NULL,'2021-06-02 13:43:42'),(7,'的',NULL,'2021-06-02 13:43:47'),(8,'个','2021-08-18 09.02.45','2021-06-07 09:47:02'),(9,'测试8','2021-08-02 14.16.35','2021-08-02 14:16:27'),(10,'计','2021-08-16 14.45.53','2021-08-16 14:45:49'),(11,'类1','2021-08-18 08.48.07','2021-08-18 08:48:00'),(12,'个','2021-08-18 09.41.43','2021-08-18 09:15:39'),(13,'个','2021-08-18 09.42.03','2021-08-18 09:17:02'),(14,'的','2021-08-18 09.24.40','2021-08-18 09:24:36'),(15,'的','2021-08-18 09.24.46','2021-08-18 09:24:42'),(16,'只','2021-08-18 09.41.35','2021-08-18 09:38:13'),(17,'只',NULL,'2021-08-18 09:45:49'),(18,'只1','2021-08-18 10.19.50','2021-08-18 10:17:06'),(19,'个',NULL,'2021-08-18 10:19:02'),(20,'个','2021-08-18 10.19.35','2021-08-18 10:19:16');
/*!40000 ALTER TABLE `chanpin_danwei` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gonhuo_xinxi`
--

DROP TABLE IF EXISTS `gonhuo_xinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gonhuo_xinxi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `gonghuo_danwe` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '供货单位',
  `gonghuo_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '供货人',
  `gonghuo_itel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '手机',
  `gonghuo_gtel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '固定电话',
  `gonghuo_dizhi` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '供货地址',
  `gonghuo_cz` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '传真',
  `ctime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '创建时间',
  `dtime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '删除时间',
  `remark_1` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `remark_2` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `remark_3` varchar(255) DEFAULT NULL,
  `remark_4` varchar(255) DEFAULT NULL,
  `remark_5` varchar(255) DEFAULT NULL,
  `remark_6` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=249 DEFAULT CHARSET=utf8mb3 COMMENT='供货单位';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gonhuo_xinxi`
--

LOCK TABLES `gonhuo_xinxi` WRITE;
/*!40000 ALTER TABLE `gonhuo_xinxi` DISABLE KEYS */;
INSERT INTO `gonhuo_xinxi` VALUES (61,'测试周1','周','18258758888','057463288888','高新区','63288471','2021-08-13 14:12:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(62,'测试周3','周','18258758890','057463288888','高新区','63288473','2021-08-13 14:12:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(63,'测试周5','周','18258758892','63288892','高新区','63288475','2021-08-13 14:12:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(64,'测试周6','周','18258758893','63288893','高新区','63288476','2021-08-13 14:12:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65,'测试周7','周','18258758894','63288894','高新区','63288477','2021-08-13 14:12:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(66,'测试周8','周','18258758894','63288894','高新区','63288477','2021-08-13 14:14:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(67,'测试周9','周','18258758894','63288894','高新区','63288477','2021-08-13 14:14:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(68,'测试周10','周','18258758894','63288894','高新区','63288477','2021-08-13 14:14:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,'慈溪加多包装材料厂','小李','13999999999','0574-88888888','慈溪市蓝田镇白云路188号','89898888','2021-06-02 13:46:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,'慈溪小牛原料厂','小牛','14978885478','111','222','333','2021-06-07 09:55:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,'慈溪阳光批发公司','陈铭','13285712265','0571-568695','浙江省慈溪市古塘街道111号','','2021-06-24 13:52:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,'宁波羊羊羊材料有限公司','王洋','13696321410','0551-5352141','宁波市慈溪市崇寿镇','','2021-06-24 13:58:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,'测试','周','18258751555','8888889','888888','888888','2021-08-02 14:20:17','2021-08-02 14:20:35',NULL,NULL,NULL,NULL,NULL,NULL),(69,'测试周11','周','18258758894','63288894','高新区','63288477','2021-08-13 14:14:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(70,'测试周12','周','18258758894','63288894','高新区','63288477','2021-08-13 14:14:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(71,'测试周13','周','18258758894','63288894','高新区','63288477','2021-08-13 14:14:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(72,'测试周14','周','18258758894','63288894','高新区','63288477','2021-08-13 14:14:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(73,'测试周66','周','18258758889','57463288888','高新区','63288472','2021-08-13 14:46:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(74,'测试周4','周','18258758891','63288891','高新区','63288474','2021-08-13 14:46:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(75,'测试周77','周','18258758892','63288892','高新区','63288475','2021-08-13 14:46:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(76,'测试周88','周','18258758892','0574-63288892','高新区','63288475','2021-08-13 14:48:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(77,'测试周888','周','18258758894','63288894','高新区','63288477','2021-08-13 14:49:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(78,'1丁赞成12312','5565.0','13285712265','0571-568695','后面的箱子','','2021-08-16 11:03:10','2021-08-17 09:32:30',NULL,NULL,NULL,NULL,NULL,NULL),(79,'1丁赞成12313','5566.0','13285712266','0571-568696','后面的箱子2','','2021-08-16 11:03:10','2021-08-17 09:32:29',NULL,NULL,NULL,NULL,NULL,NULL),(80,'丁赞成12314','5567.0','13285712267','0571-568697','','','2021-08-16 11:03:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(81,'丁赞成12315','5568.0','13285712268','0571-568698','','','2021-08-16 11:03:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(82,'1丁赞成12316','5569.0','13285712269','0571-568699','没有','','2021-08-16 11:03:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(83,'1丁赞成12317','5570.0','13285712270','0571-568700','','','2021-08-16 11:03:10','2021-08-17 09:32:16',NULL,NULL,NULL,NULL,NULL,NULL),(84,'1丁赞成12318','5571.0','13285712271','0571-568701','','','2021-08-16 11:03:10','2021-08-17 09:31:52',NULL,NULL,NULL,NULL,NULL,NULL),(85,'1丁赞成12320','5573.0','13285712273','0571-568703','','','2021-08-16 11:03:10','2021-08-17 09:31:38',NULL,NULL,NULL,NULL,NULL,NULL),(86,'1丁赞成12321','5574.0','13285712274','0571-568704','','','2021-08-16 11:03:10','2021-08-17 09:31:36',NULL,NULL,NULL,NULL,NULL,NULL),(87,'111.0','张三','13555556645','0571-888888','崇寿','0574-56565656','2021-08-17 09:32:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(88,'222.0','李四','13556987956','0572-777777','高新区','0574-12121212','2021-08-17 09:32:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(89,'123.0','礼金','13285712265','0571-568695','后面的箱子','','2021-08-17 13:13:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(90,'456.0','发顺丰','13285712267','0572-568692','后面的箱子2','','2021-08-17 13:13:10','2021-08-23 10:04:08',NULL,NULL,NULL,NULL,NULL,NULL),(91,'888.0','888.0','15288888888','888888','888888.0','123456','2021-08-17 13:13:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(92,'周1','周1','13888888899','63286955','浙江宁波慈溪高新区','63286955','2021-08-18 08:49:35',NULL,'None','None','None','None','None','None'),(93,'txys1','txys1','15557456781','123','123','123','2021-08-18 08:57:06',NULL,'aaa','','','','',''),(94,'12','22','13774859374','','','','2021-08-18 08:57:33','2021-08-18 09:03:12',NULL,NULL,NULL,NULL,NULL,NULL),(95,'123前五大双方都','12312323123123','15326844562','123123','123123','123123','2021-08-18 08:57:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(96,'五','22','13774859374','','','','2021-08-18 09:03:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(97,'txy','txy','15557456781','123','123.0','123','2021-08-23 10:39:12',NULL,'','','','','',''),(98,'周','周','13888888899','浙江宁波慈溪高新区','63286955.0','63286955','2021-08-23 10:39:12',NULL,'','','','','',''),(99,'456.0','发顺丰','13285712267','0572-568692','后面的箱子2','','2021-08-23 14:17:44',NULL,'','','','','',''),(100,'慈溪光明材料有限公司','李四','13285712265','0571-568695','浙江省宁波市慈溪市崇寿镇','888-8888','2021-08-23 16:23:15',NULL,'产品111','','','','',''),(101,'宁波吉利包装厂','张三','13285712267','0572-568692','慈溪市高新区','888-6666','2021-08-23 16:23:15',NULL,'11','产品222','','','',''),(102,'慈溪吉利包装厂','王五','13285712267','0572-568692','慈溪市高新区','888-6666','2021-08-23 16:24:03',NULL,'','产品222','','','',''),(103,'慈溪11包装厂','李六','13285712267','0572-568692','慈溪市高新区','888-6666','2021-08-23 16:26:20',NULL,'1111','产品222','222','','',''),(104,'安徽康采恩包装材料有限公司','测试','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(105,'安姆科集团毕玛时软包装(苏州)有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(106,'安平医疗器械科技（厦门）有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(107,'北京嘉恒中自图像技术有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(108,'常州爱唯康精密机械有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(109,'常州恒方大高分子材料科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(110,'辰邦医疗设备（上海）有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(111,'慈溪佳多包装材料厂','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(112,'慈溪市惠华塑胶有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(113,'慈溪市捷诚自动化设备有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(114,'慈溪市凯丽印务有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(115,'慈溪市中联泵业有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(116,'慈溪市慈佳纸制品有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(117,'慈溪市马荣烘箱有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(118,'慈溪市森泽塑料制品厂（普通合伙）','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(119,'慈溪市文达印刷厂','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(120,'大联大商贸有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(121,'东莞铂然金属材料有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(122,'东莞市博锐智科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(123,'东莞市博渊纺织品有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(124,'东莞市顺成信胶粘制品有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(125,'东莞市图锐科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(126,'东莞市宇鹏纸品有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(127,'东莞市云林应用材料有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(128,'东莞市驭舟五金制品有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(129,'东莞市耀科仪器设备有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(130,'东莞博莱德仪器设备有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(131,'东莞市泰恩斯线缆有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(132,'杜邦贸易（上海）有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(133,'佛山市尖端科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(134,'佛山市其右医疗科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(135,'广东百科机械有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(136,'广东拓斯达科技股份有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(137,'广州宝之泰电子科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(138,'广州市普利美五金塑胶有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(139,'杭州俊升科学器材有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(140,'杭州鸣辉医疗器械有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(141,'杭州泰龙净化设备工程有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(142,'杭州泽西科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(143,'杭州蓝天仪器有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(144,'杭州临安金勇精密制品有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(145,'杭州旭虹科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(146,'赫斯基注塑系统（上海）有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(147,'湖南迪文科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(148,'华函光（苏州）电子科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(149,'江阴佩尔科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(150,'卡川尔流体科技（上海）有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(151,'昆山佰塑精密机械有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(152,'昆山市玉山镇森尼尔精密模具厂','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(153,'美迪科（上海）包装材料有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(154,'南京恩得斯考博视频科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(155,'南京巨鲨显示科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(156,'南京琪胜金属精密材料有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(157,'南京高喜电子科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(158,'宁波东方长荣超声波设备有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(159,'宁波环兴环保科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(160,'宁波美高五金科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(161,'宁波欧莱克精密制管有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(162,'宁波市北仑区大契宏力起重机经营部','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(163,'宁波市驰升计量科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(164,'宁波帅羽机械设备科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(165,'宁波余慈海天机器有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(166,'宁波群英印务有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(167,'宁波天枰包装有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(168,'中国科学院宁波材料技术与工程研究院','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(169,'宁波市海曙圣科缝纫设备有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(170,'宁波怡信光电科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(171,'谱尼测试集团上海有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(172,'衢州科创包装机械有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(173,'衢州思汉医疗设备有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(174,'瑟基（宁波）医疗器械有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(175,'厦门兴惠达进出口有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(176,'上海百晟精密机械有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(177,'上海方格自动化系统有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(178,'上海海驿模具有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(179,'上海慧夏仪器设备有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(180,'上海精浦橡塑制品有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(181,'上海久罗机电设备有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(182,'上海良机冷却设备有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(183,'上海齐丰医疗器械有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(184,'上海恰艺娜实业有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(185,'上海申准计量测试技术有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(186,'上海天联材料科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(187,'上海威古医疗科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(188,'上海翔一包装机械有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(189,'上海亿林物资有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(190,'上海翊科聚合物科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(191,'上海滋源贸易有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(192,'上海任威电子科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(193,'上海凯川电子科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(194,'上海凯和实业有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(195,'蔻兰色料贸易（上海）有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(196,'上海璞临医疗科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(197,'上海鸿舟医疗器械有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(198,'上海美德电子有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(199,'上海泉福国际贸易有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(200,'上海梓穹电子科技有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(201,'绍兴上虞亿欣球业有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(202,'深圳市百事通机械设备有限公司','','','','','','2021-08-30 11:00:23',NULL,'','','','','',''),(203,'深圳市富冶金属材料有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(204,'深圳市广亚讯科技有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(205,'深圳市汉迪丰科技有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(206,'深圳市铭泰金属制品有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(207,'深圳市万鸿泰精密电路有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(208,'深圳市星立信电子贸易有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(209,'深圳市振越海绵制品有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(210,'深圳永兴耀科技有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(211,'深圳市天晟磁铁有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(212,'深圳市迪嘉机械有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(213,'深圳市隆源卓越科技发展有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(214,'深圳市海德门电子有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(215,'顶强连接器（深圳）有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(216,'苏州安美精密五金弹簧有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(217,'苏州奥珂瑞电子有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(218,'苏州工业园区艾思科技有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(219,'苏州国科医工科技发展（集团）有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(220,'苏州九皋净化科技有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(221,'苏州乐东塑料制品股份有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(222,'苏州美东汇成精密部件有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(223,'苏州欧米特光电科技有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(224,'苏州市吴中区木渎特种不锈钢材料厂','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(225,'苏州索服电子科技有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(226,'苏州系能可用性工程设计有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(227,'苏州方位无菌包装有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(228,'苏州途博塑料科技有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(229,'苏州海维尔医疗器械有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(230,'苏州诚骏科技股份有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(231,'苏州尚孚精密制造有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(232,'江苏爱芮斯医疗科技股份有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(233,'天津市医好用精密塑胶科技有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(234,'天津哈德邦斯科技发展有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(235,'温州市飞马弹簧有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(236,'温州市龙湾求精管业有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(237,'武汉华中激光产业有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(238,'余姚市明烽塑胶焊接自动化设备有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(239,'余姚市永胜塑化商行','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(240,'余姚鑫辉电器有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(241,'余姚市宝泽贸易有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(242,'余姚市科创精密零件有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(243,'张家港宏利橡塑制品有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(244,'镇江市丹徒区吉瑞机械厂','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(245,'泰州福声电子科技有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(246,'全椒县方陵电子有限公司','','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(247,'捷锐企业（上海）有限公司','测试111','','','','','2021-08-30 11:00:24',NULL,'','','','','',''),(248,'况小兵','','','','','','2021-08-30 13:06:53',NULL,'','','','','','');
/*!40000 ALTER TABLE `gonhuo_xinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_order`
--

DROP TABLE IF EXISTS `payment_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int DEFAULT NULL COMMENT '采购单id',
  `createTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '数据创建时间',
  `order_no` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '采购单据号（付款单号）',
  `reason` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '付款事由',
  `form` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '付款形式',
  `amount` decimal(11,2) DEFAULT NULL COMMENT '付款金额',
  `channel` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '付款渠道',
  `company` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '付款单位',
  `date` varchar(10) DEFAULT NULL COMMENT '支付日期',
  `payee` varchar(50) DEFAULT NULL COMMENT '收款单位/个人',
  `deposit_bank` varchar(100) DEFAULT NULL COMMENT '开户行',
  `bank_account` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '银行账户',
  `file` text COMMENT '附件JSON',
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '标题',
  `order_create_time` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '订单创建时间',
  `finish_time` datetime DEFAULT NULL COMMENT '结束时间',
  `status` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '审批状态 NEW-新创建 RUNNING-审批中 TERMINATED-被终止 COMPLETED-完成 CANCELED-取消',
  `result` varchar(20) DEFAULT NULL COMMENT '审批结果 agree-同意 refuse-拒绝',
  `business_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '审批实例业务编号',
  `biz_action` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'MODIFY：表示该审批实例是基于原来的实例修改而来\r\n\r\nREVOKE：表示该审批实例是由原来的实例撤销后重新发起的\r\n\r\nNONE表示正常发起',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_order`
--

LOCK TABLES `payment_order` WRITE;
/*!40000 ALTER TABLE `payment_order` DISABLE KEYS */;
INSERT INTO `payment_order` VALUES (1,NULL,'2021-08-25 07:35:00','XY20210825002','228项目（原电子内窥镜项目）研发样品物料预付款申请支付，总金额：9500元，预付50%，样品检验合格支付尾款。\n','[\"预付款\"]',4750.00,'转账','[\"宁波新跃医疗科技股份有限公司\"]','2021-08-26','深 圳市博美仑齿轮有限公司','中国建设银行股份有限公司深圳龙华支行','4420 1555 4000 5253 0375','[{\"spaceId\":\"886021391\",\"fileName\":\"博美仑8.25.pdf\",\"fileSize\":2145722,\"fileType\":\"pdf\",\"fileId\":\"41017714982\"}]','傅建红提交的物料付款申请','2021-08-25 15:07:37',NULL,'RUNNING',NULL,'202108251507000374741','NONE'),(2,NULL,'2021-08-25 07:35:00','XY20210825002','228项目（原电子内窥镜项目）研发样品物料申请付款，总金额：9000元，预付50%，样品检验合同支付尾款，\n行号：313331011115','[\"预付款\"]',4500.00,'转账','[\"宁波新跃医疗科技股份有限公司\"]','2021-08-26','杭州鑫泽源精密制品有限公司','江苏银行杭州海创园小微企业专营支行','3330 0188 0000 5638 0','[{\"spaceId\":\"886021391\",\"fileName\":\"鑫泽源8.25(1)(1).pdf\",\"fileSize\":625519,\"fileType\":\"pdf\",\"fileId\":\"41016655689\"}]','傅建红提交的物料付款申请','2021-08-25 14:58:37',NULL,'RUNNING',NULL,'202108251458000379259','NONE'),(3,NULL,'2021-08-25 07:35:01','XY20210825001','228项目（原电子内窥镜项目）研发样品物料付款支付申请，总金额：1024元（现货，款到发货）','[\"预付款\"]',1024.00,'转账','[\"宁波新跃医疗科技股份有限公司\"]','2021-08-26','晟昊新材料（深圳）有限公司','中国银行股份有限公司深圳龙华支行','7614 6422 2984','[{\"spaceId\":\"886021391\",\"fileName\":\"晟昊8.24(1).pdf\",\"fileSize\":382868,\"fileType\":\"pdf\",\"fileId\":\"41015828905\"}]','傅建红提交的物料付款申请','2021-08-25 14:52:10',NULL,'RUNNING',NULL,'202108251452000098477','NONE'),(4,NULL,'2021-08-25 07:35:01','XY20210825001','228项目（原电子内窥镜项目）研发样品物料付款申请，多腔管挤出模具预付款；总金额：10000元，预付50%，产品验收合格后支付尾款。','[\"预付款\"]',5000.00,'转账','[\"宁波新跃医疗科技股份有限公司\"]','2021-08-26','昆山市玉山镇森尼尔精密模具厂','昆山农村商业银行','3052 2580 1201 3000 0008 17','[{\"spaceId\":\"886021391\",\"fileName\":\"森尼尔8.24.pdf\",\"fileSize\":918917,\"fileType\":\"pdf\",\"fileId\":\"41012041573\"}]','傅建红提交的物料付款申请','2021-08-25 14:20:46',NULL,'RUNNING',NULL,'202108251420000465575','NONE'),(5,NULL,'2021-08-25 07:35:01','XY20210825001','228项目（原电子内窥镜项目）研发样品物料付款申请，总金额：4500（款到发货）','[\"预付款\"]',4500.00,'转账','[\"宁波新跃医疗科技股份有限公司\"]','2021-08-26','嘉兴易索精密仪器有限公司','中国银行浙江长三角一体化示范区支行营业部','3766 6744 4460','[{\"spaceId\":\"886021391\",\"fileName\":\"易索8.24.pdf\",\"fileSize\":1637200,\"fileType\":\"pdf\",\"fileId\":\"41009063871\"}]','傅建红提交的物料付款申请','2021-08-25 13:53:58',NULL,'COMPLETED','agree','202108251353000572187','NONE'),(6,NULL,'2021-08-25 07:35:01','XY20210825002','228项目（原电子内窥镜项目）研发样品物料购买，预付款申请，总金额：640元（款到发货）','[\"预付款\"]',640.00,'转账','[\"宁波新跃医疗科技股份有限公司\"]','2021-08-26','佛山市埃立自贸易有限公司','农业银行佛山南海怡翠支行','4450 5101 0400 0250 9','[{\"spaceId\":\"886021391\",\"fileName\":\"埃立8.25(1).pdf\",\"fileSize\":489809,\"fileType\":\"pdf\",\"fileId\":\"41005187268\"}]','傅建红提交的物料付款申请','2021-08-25 12:57:05',NULL,'COMPLETED','agree','202108251257000042862','NONE'),(7,NULL,'2021-08-25 07:35:02','XY20210825002','别良伟项目组---数字胸腔引流系统测试和样机用物料 4100.00元全额付款','[\"预付款\"]',4100.00,'转账','[\"宁波新跃医疗科技股份有限公司\"]','2021-08-26','南京润泽流体控制设备有限公司','中国农业银行股份有限公司际购东麒路支行','1013 1001 0400 0345 1','[{\"spaceId\":\"886021391\",\"fileName\":\"8.25宁波新跃医疗科技股份有限公司.pdf\",\"fileSize\":383900,\"fileType\":\"pdf\",\"fileId\":\"40991324900\"}]','况小兵提交的物料付款申请','2021-08-25 10:28:07',NULL,'COMPLETED','agree','202108251028000068871','NONE'),(8,NULL,'2021-08-31 02:39:59','PO202108181165/PO202108271193','采购订单全额付款：总金额4624.00元（购买油墨）','[\"预付款\"]',4624.00,'转账','[\"宁波新跃医疗科技股份有限公司\"]','2021-09-01','徐州美成油墨有限公司','工商银行丰县凤城分理处','1106 0706 0920 0020 083','[{\"spaceId\":\"886021391\",\"fileName\":\"美成8.18(1).pdf\",\"fileSize\":400314,\"fileType\":\"pdf\",\"fileId\":\"41600538354\"},{\"spaceId\":\"886021391\",\"fileName\":\"美成8.27.pdf\",\"fileSize\":421141,\"fileType\":\"pdf\",\"fileId\":\"41600498692\"}]','况小兵提交的物料付款申请','2021-08-31 10:37:01',NULL,'COMPLETED','agree','202108311037000008335','NONE'),(9,NULL,'2021-08-31 02:54:59','KQD20210830 ','无纺布样品购买：全额付款：980.00','[\"预付款\"]',980.00,'转账','[\"宁波新跃医疗科技股份有限公司\"]','2021-09-01','宁波科琦达塑胶科技有限公司','浦发银行宁波高新区支行','9413 0154 7400 0183 3','[{\"spaceId\":\"886021391\",\"fileName\":\"KQD20210830  科琦达.pdf\",\"fileSize\":189471,\"fileType\":\"pdf\",\"fileId\":\"41602878036\"}]','况小兵提交的物料付款申请','2021-08-31 10:52:21',NULL,'COMPLETED','agree','202108311052000217529','NONE');
/*!40000 ALTER TABLE `payment_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test` (
  `name` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
INSERT INTO `test` VALUES ('1');
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wuliao_lei`
--

DROP TABLE IF EXISTS `wuliao_lei`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wuliao_lei` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物料名',
  `ctime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '创建时间',
  `dtime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3 COMMENT='物料类别表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wuliao_lei`
--

LOCK TABLES `wuliao_lei` WRITE;
/*!40000 ALTER TABLE `wuliao_lei` DISABLE KEYS */;
INSERT INTO `wuliao_lei` VALUES (1,'包装材料类','2021-05-31 09:28:22',NULL),(2,'物料22','2021-05-31 09:28:42','2021-05-31 09.28.55'),(3,'包装材料类2','2021-06-02 13:38:20',NULL),(4,'包装材料类3','2021-06-07 09:46:37','2021-08-18 09.00.48'),(5,'测试9998','2021-08-02 14:15:58','2021-08-02 14.16.05'),(6,'一次性器械一次性医疗器械','2021-08-16 14:44:38','2021-08-16 14.45.21'),(7,'一次性','2021-08-16 14:45:28','2021-08-16 14.45.32'),(8,'一次性器械','2021-08-17 10:18:48','2021-08-17 10.19.26'),(9,'一次性医疗器械','2021-08-17 10:19:06','2021-08-17 10.19.24'),(10,'包装材料类4','2021-08-18 08:46:07','2021-08-18 08.47.47'),(11,'供货单位管理','2021-08-18 08:46:33','2021-08-18 08.47.44'),(12,'78788','2021-08-18 08:47:16','2021-08-18 08.47.20'),(13,'医疗器械管理','2021-08-18 08:47:28','2021-08-18 08.47.42'),(14,'123123123','2021-08-18 09:01:16','2021-08-18 09.34.45'),(15,'包装材料类3','2021-08-18 09:13:57',NULL),(16,'包装材料类4','2021-08-18 09:14:18',NULL),(17,'包装材料类','2021-08-18 09:34:52',NULL),(18,'包装材料类','2021-08-18 09:37:12',NULL),(19,'包装材料类','2021-08-18 09:37:16',NULL),(20,'包装材料类','2021-08-18 09:37:18',NULL),(21,'包装材料类6','2021-08-18 09:44:38','2021-08-18 09.44.51'),(22,'包装材料类5','2021-08-18 09:44:57',NULL),(23,'一次性器械','2021-08-18 09:49:18',NULL),(24,'一次性器械1','2021-08-18 10:16:49','2021-08-18 10.16.56'),(25,'一次性1','2021-08-18 10:20:24',NULL);
/*!40000 ALTER TABLE `wuliao_lei` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_order`
--

DROP TABLE IF EXISTS `x_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `x_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` varchar(225) NOT NULL COMMENT '订单号',
  `wuliao_lei` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '物料类别',
  `canpin_name` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品名',
  `canpin_guige` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品规格',
  `canpin_pinpai` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品品牌',
  `canpin_danwei` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '供货单位',
  `canpin_shu` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '数量',
  `canpin_danjia` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品单价',
  `canpin_shuilv` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '税率',
  `canpin_zongjia` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '总价',
  `canpin_endtime` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '交付时间',
  `caigou_name` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '采购人',
  `gonghuo_name` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '供货人',
  `gonghuo_danwe` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '供货单位',
  `gonghuo_itel` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '手机号',
  `gonghuo_gtel` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '固定电话',
  `gonghuo_dizhi` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '供货地址',
  `gonghuo_cz` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '供货传真',
  `hetong_endtime` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '合同交付时间',
  `fukan_fangshi` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '付款方式',
  `kaipiao_time` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '开票时间',
  `fapiao_hao` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票号',
  `yufu_kuan` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '预付款',
  `yufu_time` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '预付时间',
  `zhongqi_kuan` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '中期款',
  `zhongqi_time` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '中期款时间',
  `yukuan` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '余款',
  `yukuan_time` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '余款时间',
  `gaizhang_type` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '盖章状态',
  `fapiao_type` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '发票状态',
  `fujian_url` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '附件url',
  `ctime` datetime DEFAULT CURRENT_TIMESTAMP,
  `dtime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '删除时间',
  `orderid` int NOT NULL COMMENT '申请单id',
  `uid` int unsigned DEFAULT NULL COMMENT '接单人的id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb3 COMMENT='采购单表(子)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_order`
--

LOCK TABLES `x_order` WRITE;
/*!40000 ALTER TABLE `x_order` DISABLE KEYS */;
INSERT INTO `x_order` VALUES (131,'XY20210825001','','测试','','','','100','1003','','100300','','胡刚','张三','宁波吉利包装厂','13285712267','0572-568692','慈溪市高新区','888-6666','2021-08-19','','','','','','','','','','','已签字','','2021-08-25 10:45:26',NULL,80,30),(132,'XY20210825002','','123','','','的','2','1','','2','','胡刚','李六','慈溪11包装厂','13285712267','0572-568692','慈溪市高新区','888-6666','2021-08-25','','','','','','','','','','已审批','已签字','','2021-08-25 13:39:46',NULL,80,30);
/*!40000 ALTER TABLE `x_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_orders`
--

DROP TABLE IF EXISTS `x_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `x_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dingding_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '申请人',
  `dingding_bumen` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '部门',
  `dingding_xm` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '项目名',
  `dingding_endtime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '最后交付时间',
  `dingding_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '采购类型',
  `xiadan_time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '申请时间',
  `dtime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '删除时间',
  `typess` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '取消单标记',
  `typess_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '取消者',
  `typess_body` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '取消原因',
  `typess_time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '取消时间',
  `dd_file` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '钉钉附件',
  `uid` int DEFAULT NULL COMMENT '接申请单者id',
  `yingyong` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '应用方向',
  `zongjia` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '预计总价',
  `kdanwei` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '开票单位',
  `sfdz` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '送货地址',
  `sfr` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '收货人',
  `tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '电话',
  `bz` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '备注',
  `canpin_name_f` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '产品名',
  `canpin_guige_f` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '规格',
  `canpin_shu_f` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '数量',
  `caigou_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `cc_time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `send_ctime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `business_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `process_instance_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='采购申请信息表（父）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_orders`
--

LOCK TABLES `x_orders` WRITE;
/*!40000 ALTER TABLE `x_orders` DISABLE KEYS */;
INSERT INTO `x_orders` VALUES (94,'温合兴','研发','数字胸腔引流系统（结构部分，系统集成）','2021-08-27','其他','2021-08-25 21:40:25',NULL,NULL,NULL,NULL,NULL,'[{\'name\': \'微型拉压力传感器DYLY-106.xls\', \'url\': \'http://smart.park.xinhai.com/微型拉压力传感器DYLY-106.xls\'}]',24,'数字胸腔引流系统---称重传感器结构性能确认','550','宁波新跃医疗科技股份有限公司','上海科创中心','温合兴','15151644015','0~20KG的，规格详见附档','微型拉压力传感器','见附档','4','况小兵','2021-08-26 17:41:06','2021-08-26 17:41:06','202108252140000247411','8104e569-a579-44c7-8880-68683547b82c'),(95,'蔡兆春','研发部','一次性使用取石球囊','2021-08-17','原料','2021-08-24 18:16:25',NULL,NULL,NULL,NULL,NULL,'[{\'name\': \'囊体-15(2).pdf\', \'url\': \'http://smart.park.xinhai.com/囊体-15(2).pdf\'}]',24,'一次性使用取石球囊/项目代号122','9000','宁波新跃医疗科技股份有限公司','其他（请在备注填写）','蔡兆春','18751860693','1、收货地址：浙江省慈溪高新技术产业开发区滨江路188号，宁波新跃医疗科技股份有限公司；\n2、囊体（15）对应成品规格为EB-21-23-B，是做为典型性规格EB-15/18/21-23-B的结构差异比较分析的，特此申请','囊体（15）','1.8*9','300','漆爱国','2021-08-26 17:41:44','2021-08-26 16:53:38','202108241816000240442','459ec7e4-2d01-404d-b70a-7cb4aa44c997'),(96,'马旭岩','上海科创中心','数字胸腔引流系统（软件、硬件部分）','2021-08-23','其他','2021-08-21 15:58:45',NULL,NULL,NULL,NULL,NULL,'[{\'name\': \'屏幕来料检测工装物料采购清单0821.xlsx\', \'url\': \'http://smart.park.xinhai.com/屏幕来料检测工装物料采购清单0821.xlsx\'}]',30,'数字胸腔引流系统','150','新海科技集团有限公司','上海科创中心','马旭岩','15867407527','淘宝购买 开不了发票开收据就行','数字胸腔引流系统屏幕检测工装物料采购','','120','胡刚','2021-08-23 12:47:55','2021-08-22 07:13:03','202108211558000440245','7ae50ef7-f2fe-4d80-85b5-063615a0f046'),(97,'王路强','新跃研发部','通用项目','2021-08-29','其他','2021-08-20 15:57:21',NULL,NULL,NULL,NULL,NULL,'',25,'','500','新海科技集团有限公司','新跃医疗高新区分厂','王路强','15700129260','图纸及加工明细已发给傅建红','肾盂模型固定板','','2','傅建红','2021-08-23 17:36:38','2021-08-23 13:41:00','202108201557000215657','f1bf2e75-5119-4374-9676-d5644e9e27b3'),(98,'王飞','研发','数字胸腔引流系统（结构部分，系统集成）','','其他','2021-08-29 09:42:39',NULL,NULL,NULL,NULL,NULL,'[{\'name\': \'数字胸腔引流系统仪器采购20210826(2).xlsx\', \'url\': \'http://smart.park.xinhai.com/数字胸腔引流系统仪器采购20210826(2).xlsx\'}]',30,'','760','','上海科创中心','王飞','18913651195','','热电偶线','','60','胡刚','2021-08-30 11:09:51','2021-08-30 08:00:09','202108290942000380579','bf36db3b-31eb-4e44-8630-a32d880206e0'),(99,'岑升亮','研发，质量','一次性使用水封胸腔引流装置','2021-09-10','其他','2021-08-27 14:35:58',NULL,NULL,NULL,NULL,NULL,'',28,'用于二腔瓶瓶体注塑时测量瓶体高度及其他产品高度测量','700','宁波新跃医疗科技股份有限公司','新跃医疗高新区分厂','岑升亮','15168137057','工作台面不能小于400*300mm  高度不低于350mm','高度测量工作平台','','1','况小兵','2021-08-31 09:03:37','2021-08-31 09:03:37','202108271435000574356','4a342a54-c1c0-4088-bf49-4b664a770b7c'),(100,'马旭岩','上海科创中心','ESD电刀（软件、硬件部分）','2021-08-30','其他','2021-08-27 08:57:14',NULL,NULL,NULL,NULL,NULL,'[{\'name\': \'氩气控制器板子调试工具购买.xls\', \'url\': \'http://smart.park.xinhai.com/氩气控制器板子调试工具购买.xls\'}]',30,'氩气控制器','420','其他（可在备注栏补充）','上海科创中心','马旭岩','15867407527','','氩气控制器板子调试工具','','4','胡刚','2021-08-30 09:59:04','2021-08-28 18:35:12','202108270857000141871','f29d096a-9979-4df6-abdc-438a77c9d82e'),(101,'王薛','上海科创中心（ERCP项目）','一次性使用乳头括约肌切开刀','2021-08-31','其他','2021-08-25 22:12:41',NULL,NULL,NULL,NULL,NULL,'[{\'name\': \'防静电绝缘皮.docx\', \'url\': \'http://smart.park.xinhai.com/防静电绝缘皮.docx\'}]',26,'一次性使用切开刀（211）','300','宁波新跃医疗科技股份有限公司','新跃医疗高新区分厂','王薛','18071606187','防静电绝缘皮1.2米×5米×3mm','防静电绝缘皮','1.2米×5米×3mm','1','况小兵','2021-08-27 12:22:49','2021-08-26 16:55:59','202108252212000405860','4703b645-665c-43b8-8804-b18d3f843b56'),(102,'马旭岩','上海科创中心','ESD电刀（软件、硬件部分）','2021-09-02','其他','2021-08-31 16:35:02',NULL,NULL,NULL,NULL,NULL,'[{\'name\': \'立创商城购物车详情210831.xls\', \'url\': \'http://smart.park.xinhai.com/立创商城购物车详情210831.xls\'}]',30,'氩气控制器','200','新海科技集团有限公司','上海科创中心','马旭岩','15867407527','','立创商城物料采购','','2000','胡刚','2021-09-01 09:21:11',NULL,'202108311635000029402','c8a7cfff-5cb2-4195-b2d9-13b2d26721d5'),(103,'蔡兆春','研发部','一次性使用取石球囊','2021-09-03','其他','2021-08-25 18:53:47',NULL,NULL,NULL,NULL,NULL,'[{\'name\': \'15mm球囊-定尺工装加工需求清单.xls\', \'url\': \'http://smart.park.xinhai.com/15mm球囊-定尺工装加工需求清单.xls\'}, {\'name\': \'15mm球囊-定尺工装总装.pdf\', \'url\': \'http://smart.park.xinhai.com/15mm球囊-定尺工装总装.pdf\'}, {\'name\': \'15mm球囊-定尺工装总装.STEP\', \'url\': \'http://smart.park.xinhai.com/15mm球囊-定尺工装总装.STEP\'}]',25,'一次性使用取石球囊/项目代码122','500','宁波新跃医疗科技股份有限公司','新跃医疗高新区分厂','蔡兆春','18751860693','此工装裁切的是15mm囊体，囊体形状为圆形柱状，不可以与21囊体裁切工装共用','15mm球囊-定尺工装','','1','傅建红','2021-08-31 17:16:25',NULL,'202108251853000462410','6669aabe-4fc5-47e9-9624-396adcb36062');
/*!40000 ALTER TABLE `x_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_user`
--

DROP TABLE IF EXISTS `x_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `x_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users` varchar(255) DEFAULT NULL COMMENT '账号  废弃',
  `passwd` varchar(255) DEFAULT NULL COMMENT '密码',
  `name` varchar(255) DEFAULT NULL COMMENT '名字',
  `gonghao` varchar(255) DEFAULT NULL COMMENT '工号 登录名',
  `ziwei` varchar(255) DEFAULT NULL COMMENT '职位',
  `tel` varchar(255) DEFAULT NULL COMMENT '电话',
  `dtime` varchar(225) DEFAULT NULL COMMENT '删除时间',
  `ctime` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users` (`gonghao`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_user`
--

LOCK TABLES `x_user` WRITE;
/*!40000 ALTER TABLE `x_user` DISABLE KEYS */;
INSERT INTO `x_user` VALUES (1,'root','root','管理员帐号','820012','管理员','13285712265',NULL,'2021-05-12 10:41:47'),(2,'admin','root','杨杰','820013','采购员','13285712265','2021-08-19 10.48.17','2021-05-07 11:16:17'),(3,'66666','66666','张三三','820019','采购员','15935785222','2021-08-19 10.48.15','2021-05-08 16:21:33'),(4,'str','str','陈莎莉','820090','管理员','13652212012','2021-08-19 10.48.12','2021-05-11 13:33:58'),(5,'root1','root','况小兵','820011','采购员','13285712265','2021-08-19 10.48.11','2021-05-12 10:41:47'),(22,'','123','张三','800000','采购员','13444453646','2021-08-19 10.47.59','2021-08-19 10:03:57'),(14,'li','123456','陈晓明','120000','采购员','13999999999','2021-08-19 10.48.09','2021-06-02 14:33:29'),(15,'wangwu','123','王五','10203040','采购员','13888889990','2021-08-19 10.48.07','2021-06-07 09:42:04'),(16,'','123456','周周','820028','采购员','18258758888','2021-08-19 10.48.06','2021-08-02 14:08:35'),(17,'','123456','岑柯','820030','采购员','13999999999','2021-08-19 10.48.04','2021-08-04 09:03:35'),(18,'','123456','杨克','820065','采购员','13998886536','2021-08-19 10.48.02','2021-08-04 13:39:12'),(23,'','6003','茹宏业','916003','管理员','13968259768',NULL,'2021-08-19 12:58:18'),(24,'','123','漆爱国','915051','采购员','18118157606',NULL,'2021-08-19 12:58:57'),(25,'','123','傅建红','600602','采购员','13857454593',NULL,'2021-08-19 12:59:49'),(26,'','500113','况小兵','916101','管理员','13095956889',NULL,'2021-08-19 13:00:26'),(27,'','123','罗立溢','916105','采购员','15257436892',NULL,'2021-08-19 13:01:00'),(28,'','123','岑珂','916102','采购员','18868624936',NULL,'2021-08-19 13:01:24'),(29,'','00787','应函希','916106','采购员','15057400787',NULL,'2021-08-19 13:01:47'),(30,'','123','胡刚','820016','采购员','18916050350',NULL,'2021-08-19 13:02:18');
/*!40000 ALTER TABLE `x_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xm_name`
--

DROP TABLE IF EXISTS `xm_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xm_name` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '项目名',
  `dtime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '删除时间',
  `ctime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 COMMENT='项目名称表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xm_name`
--

LOCK TABLES `xm_name` WRITE;
/*!40000 ALTER TABLE `xm_name` DISABLE KEYS */;
INSERT INTO `xm_name` VALUES (1,'003-吻合器项目',NULL,'2021-05-31 09:15:47'),(2,'香奴2','2021-05-31 09.22.44','2021-05-31 09:21:28'),(3,'002-视频喉镜项目',NULL,'2021-05-31 09:22:54'),(4,'001-美联订单项目',NULL,'2021-06-02 13:33:56'),(5,'004-ERCP项目（消化内科）',NULL,'2021-06-07 09:44:35'),(6,'005-电子内窥镜项目',NULL,'2021-06-07 09:44:49'),(7,'006-结扎夹项目',NULL,'2021-06-07 09:45:03'),(8,'007-泌尿项目',NULL,'2021-06-07 09:45:16'),(9,'测试9998','2021-08-02 14.15.42','2021-08-02 14:15:33'),(10,'测试','2021-08-02 14.17.23','2021-08-02 14:17:10'),(11,'888','2021-08-02 14.17.21','2021-08-02 14:17:18');
/*!40000 ALTER TABLE `xm_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'x_caigou2'
--

--
-- Dumping routines for database 'x_caigou2'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-09-15  9:58:35
